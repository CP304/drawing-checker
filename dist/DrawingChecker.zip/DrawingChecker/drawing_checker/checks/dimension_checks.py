"""Bemaßungs- und Fertigungsprüfungen.

Deckt die klassischen Bemaßungsfehler (ISO 129-1 / DIN 406) und die
typischen Kostentreiber der Zerspanung ab:

  DIM.CHAIN        Geschlossene Maßkette: Teilmaße summieren sich exakt zum
                   Gesamtmaß und alle sind toleriert -> Toleranzkonflikt
                   (Überbestimmung, das Maß ist doppelt festgelegt).
  DIM.NO_TOLERANCE Kein einziges Maß trägt eine Einzeltoleranz, obwohl
                   Passungen/Funktionsmaße zu erwarten wären.
  MFG.TIGHT_TOL    Sehr enge Toleranz (IT ≤ 5 bzw. Spanne < 0,01 mm) –
                   starker Kostentreiber, nur bei Funktionsbedarf sinnvoll.
  MFG.DEEP_HOLE    Bohrungstiefe/Durchmesser > 5 – Tiefbohren nötig.
  MFG.SHARP_CORNER "R0" bzw. scharfe Innenecke gefordert – mit Fräser nicht
                   herstellbar (Erodieren nötig).
  SURF.UNREALISTIC Rauheit feiner als das angegebene Verfahren liefern kann
                   (z. B. Ra 0,2 auf einer Gussfläche).
  SURF.TOL_MISMATCH Rauheit zu grob für die geforderte Toleranz – eine
                   H7-Passung lässt sich mit Rz 63 nicht einhalten, weil
                   das Rauheitsprofil selbst schon die halbe Toleranz
                   verbraucht.
  DIM.TOL_ORDER    Grenzabmaße vertauscht (oberes Abmaß kleiner als das
                   untere) – das Maß ist so nicht fertigbar.
  DIM.BASIC_TOL    Theoretisch genaues Maß (eingerahmt) zusätzlich
                   toleriert – Widerspruch nach ISO 1101.
  THRD.DEPTH       Gewinde tiefer gefordert als die Bohrung – so nicht
                   herstellbar (der Bohrer kommt nicht weiter).
  THRD.SHORT       Einschraubtiefe unter 1×D – die Verbindung trägt die
                   Schraubenfestigkeit nicht.
"""
from __future__ import annotations

import re
from itertools import combinations

from ..drawing.dimensions import DimKind, DimValue
from .base import CheckContext

RE_SHARP_CORNER = re.compile(
    r"\bR\s*0(?![.,]\d*[1-9])\b|scharfkantig\s+innen|sharp\s+internal"
    r"|keine\s+radien|no\s+corner\s+radius|ecke\s+scharf", re.IGNORECASE)
RE_RA_VALUE = re.compile(r"\bRa\s*(\d+(?:[.,]\d+)?)", re.IGNORECASE)
RE_RZ_VALUE = re.compile(r"\bRz\s*(\d+(?:[.,]\d+)?)", re.IGNORECASE)
# Verfahren mit ihrer praktisch erreichbaren Feinheit (Ra in µm).
PROCESS_RA_LIMIT = {
    "guss": (re.compile(r"\bguss|casting|\bcast\b|EN[-\s]?GJ|rohteil"
                        r"|unbearbeitet|as[-\s]cast", re.IGNORECASE), 6.3),
    "brennschnitt": (re.compile(r"brennschnitt|autogen|plasmaschnitt"
                                r"|flame[-\s]cut", re.IGNORECASE), 12.5),
    "schmieden": (re.compile(r"geschmiedet|schmiedeteil|forged",
                             re.IGNORECASE), 6.3),
}
# Verfahren, die sehr feine Oberflächen rechtfertigen.
RE_FINE_PROCESS = re.compile(
    r"geschliffen|schleifen|läppen|honen|poliert|ground|lapped|honed"
    r"|polished|superfinish", re.IGNORECASE)


def _axis_groups(dims: list[DimValue], tol: float
                 ) -> list[tuple[str, list[DimValue]]]:
    """Gruppiert Maße zu möglichen Maßketten (gleiche Maßlinie).

    Horizontale Kette: Maßtexte liegen auf gleicher Höhe (y), nebeneinander.
    Vertikale Kette: gleiche Spalte (x), untereinander.
    """
    groups: list[tuple[str, list[DimValue]]] = []
    for axis, key, other in (("h", lambda d: d.bbox.center[1],
                              lambda d: d.bbox.center[0]),
                             ("v", lambda d: d.bbox.center[0],
                              lambda d: d.bbox.center[1])):
        buckets: dict[int, list[DimValue]] = {}
        for d in dims:
            buckets.setdefault(int(key(d) / tol), []).append(d)
        # Nachbarschaftsbuckets zusammenführen (Maßtexte sitzen nicht exakt
        # auf derselben Koordinate).
        merged: dict[int, list[DimValue]] = {}
        for b, items in sorted(buckets.items()):
            target = merged.get(b - 1)
            if target is not None:
                merged[b - 1] = target + items
            else:
                merged[b] = list(items)
        for items in merged.values():
            if len(items) >= 3:
                groups.append((axis, sorted(items, key=other)))
    return groups


def _is_adjacent_chain(parts: list[DimValue], axis: str) -> bool:
    """Teilmaße müssen nebeneinander liegen (keine Überlappung)."""
    spans = []
    for d in parts:
        b = d.bbox
        spans.append((b.x0, b.x1) if axis == "h" else (b.y0, b.y1))
    spans.sort()
    for (_, end), (start, _) in zip(spans, spans[1:]):
        if start < end - 1.0:      # deutliche Überlappung -> keine Kette
            return False
    return True


def check_dimension_chain(ctx: CheckContext, dims: list[DimValue]) -> None:
    """Geschlossene, durchtolerierte Maßkette erkennen.

    Eine echte Kette erfüllt drei Bedingungen gleichzeitig:
      1. die Teilmaße liegen auf EINER Maßlinie und nebeneinander,
      2. ihre Summe ergibt ein weiteres Maß derselben Richtung,
      3. Gesamtmaß und mehrere Teilmaße sind toleriert.
    Ohne die räumliche Prüfung liefert die reine Zahlensuche auf
    maßreichen Zeichnungen Zufallstreffer.
    """
    if not ctx.profile.enabled("DIM.CHAIN"):
        return
    linear = [d for d in dims if d.kind is DimKind.LINEAR and d.value >= 5]
    if len(linear) < 4:
        return
    eps = float(ctx.profile.params.get("chain_epsilon", 0.05))
    line_tol = float(ctx.profile.params.get("chain_line_tol", 8.0))
    reported = 0

    for axis, group in _axis_groups(linear, line_tol):
        toler = [d for d in group if d.tolerance_span]
        if len(toler) < 2:
            continue
        # Kandidaten für das Gesamtmaß: toleriert und größer als der Rest
        for total in sorted(toler, key=lambda d: -d.value):
            parts_pool = [d for d in group
                          if d is not total and d.value < total.value]
            if len(parts_pool) < 2:
                continue
            found = None
            for n in (2, 3, 4):
                if n > len(parts_pool):
                    break
                for combo in combinations(parts_pool, n):
                    if abs(sum(d.value for d in combo) - total.value) > eps:
                        continue
                    if sum(1 for d in combo if d.tolerance_span) < 1:
                        continue
                    if not _is_adjacent_chain(list(combo), axis):
                        continue
                    found = combo
                    break
                if found:
                    break
            if not found:
                continue
            chain = " + ".join(f"{d.value:g}" for d in found)
            ctx.add("DIM.CHAIN",
                    f"Geschlossene Maßkette mit Toleranzkonflikt: "
                    f"{chain} = {total.value:g}, Teil- und Gesamtmaß toleriert",
                    bbox=total.bbox, page=total.page,
                    detail="Bei geschlossenen Ketten summieren sich die "
                           "Einzeltoleranzen; ein Maß muss als Hilfsmaß "
                           "(eingeklammert) oder ohne Toleranz ausgeführt "
                           "werden (ISO 129-1, DIN 406-11).")
            reported += 1
            if reported >= 2:
                return
            break


def check_tight_tolerances(ctx: CheckContext, dims: list[DimValue]) -> None:
    """Sehr enge Toleranzen als Kostentreiber melden."""
    if not ctx.profile.enabled("MFG.TIGHT_TOL"):
        return
    limit_mm = float(ctx.profile.params.get("tight_tol_mm", 0.01))
    limit_it = int(ctx.profile.params.get("tight_tol_it", 5))
    tight = []
    for d in dims:
        span = d.tolerance_span
        grade = d.it_grade
        if (span is not None and span < limit_mm) or (
                grade is not None and grade <= limit_it):
            tight.append(d)
    if not tight:
        return
    max_report = int(ctx.profile.params.get("max_tight_tol_markers", 5))
    for d in tight[:max_report]:
        span = d.tolerance_span
        grade_txt = f" (IT{d.it_grade})" if d.it_grade else ""
        span_txt = f"{span * 1000:.0f} µm" if span else "sehr eng"
        ctx.add("MFG.TIGHT_TOL",
                f"Sehr enge Toleranz: {d.raw} → {span_txt}{grade_txt}",
                bbox=d.bbox, page=d.page,
                detail="Enge Toleranzen sind der stärkste Kostentreiber in "
                       "der Zerspanung (Sonderwerkzeuge, Messmittel, "
                       "Ausschussrisiko). Nur an funktionsrelevanten Maßen "
                       "vorsehen.")
    if len(tight) > max_report:
        ctx.add("MFG.TIGHT_TOL",
                f"… und {len(tight) - max_report} weitere sehr enge Toleranzen",
                detail="Nur die ersten Fundstellen sind im Bild markiert.")


def check_deep_holes(ctx: CheckContext, dims: list[DimValue]) -> None:
    """Tiefe Bohrungen (Tiefe/Durchmesser > Schwelle)."""
    if not ctx.profile.enabled("MFG.DEEP_HOLE"):
        return
    ratio_limit = float(ctx.profile.params.get("deep_hole_ratio", 5.0))
    for d in dims:
        if d.kind not in (DimKind.DIAMETER, DimKind.THREAD) or not d.depth:
            continue
        if d.value <= 0:
            continue
        ratio = d.depth / d.value
        if ratio > ratio_limit:
            ctx.add("MFG.DEEP_HOLE",
                    f"Tiefe Bohrung: ⌀{d.value:g} × {d.depth:g} mm tief "
                    f"(Verhältnis {ratio:.1f}:1)",
                    bbox=d.bbox, page=d.page,
                    detail="Ab etwa 5:1 sind Tiefbohrwerkzeuge, "
                           "Spanbruchstrategien und ggf. Innenkühlung nötig – "
                           "Kosten und Lieferzeit steigen deutlich.")


def check_sharp_corners(ctx: CheckContext) -> None:
    """Scharfe Innenecken bzw. R0 gefordert."""
    if not ctx.profile.enabled("MFG.SHARP_CORNER"):
        return
    for b in ctx.pdf.blocks():
        m = RE_SHARP_CORNER.search(b.text)
        if m:
            ctx.add("MFG.SHARP_CORNER",
                    f"Scharfe Innenecke gefordert („{m.group(0)}“)",
                    bbox=b.bbox, page=b.page,
                    detail="Fräser erzeugen immer einen Eckenradius. Scharfe "
                           "Innenecken erfordern Erodieren oder Räumen – "
                           "Eckenradius zulassen, wenn funktional möglich.")
            return


def check_surface_plausibility(ctx: CheckContext) -> None:
    """Rauheitsangabe feiner, als das genannte Verfahren liefern kann."""
    if not ctx.profile.enabled("SURF.UNREALISTIC"):
        return
    text = ctx.pdf.full_text()
    if RE_FINE_PROCESS.search(text):
        return  # Feinbearbeitung ist angegeben -> plausibel
    ra_values = [float(v.replace(",", ".")) for v in RE_RA_VALUE.findall(text)]
    if not ra_values:
        return
    finest = min(ra_values)
    for name, (regex, limit) in PROCESS_RA_LIMIT.items():
        m = regex.search(text)
        if m and finest < limit / 4:
            ctx.add("SURF.UNREALISTIC",
                    f"Rauheit Ra {finest:g} µm bei Verfahren „{m.group(0)}“ "
                    f"nicht erreichbar",
                    detail=f"Ohne Nachbearbeitung liefert dieses Verfahren "
                           f"etwa Ra {limit} µm. Entweder Feinbearbeitung "
                           f"(Schleifen/Honen) vorgeben oder die "
                           f"Rauheitsforderung anpassen.")
            return
    # Sehr feine Rauheit ohne jedes Feinbearbeitungsverfahren
    fine_limit = float(ctx.profile.params.get("fine_ra_limit", 0.4))
    if finest < fine_limit:
        ctx.add("SURF.UNREALISTIC",
                f"Sehr feine Rauheit Ra {finest:g} µm ohne Angabe eines "
                f"Feinbearbeitungsverfahrens",
                severity=ctx.profile.severity("SURF.UNREALISTIC_MINOR"),
                detail="Ra < 0,4 µm erfordert Schleifen, Honen oder Läppen – "
                       "Verfahren angeben, sonst kalkuliert der Lieferant "
                       "auf Verdacht.")


def check_tolerance_order(ctx: CheckContext, dims: list[DimValue]) -> None:
    """Vertauschte Grenzabmaße und tolerierte TED-Maße melden."""
    for d in dims:
        if (ctx.profile.enabled("DIM.TOL_ORDER")
                and d.tol_plus is not None and d.tol_minus is not None
                and d.tol_plus < d.tol_minus):
            ctx.add("DIM.TOL_ORDER",
                    f"Grenzabmaße vertauscht bei „{d.raw}“: oberes Abmaß "
                    f"{d.tol_plus:+g} liegt unter dem unteren "
                    f"{d.tol_minus:+g}",
                    bbox=d.bbox, page=d.page,
                    detail="So beschrieben ist das Toleranzfeld leer – das "
                           "Maß kann nicht gefertigt werden. Nach ISO 129-1 "
                           "steht das obere Abmaß oben bzw. zuerst.")
        if (ctx.profile.enabled("DIM.BASIC_TOL") and d.is_basic
                and (d.tol_plus is not None or d.tol_minus is not None
                     or d.fit)):
            ctx.add("DIM.BASIC_TOL",
                    f"Theoretisch genaues Maß „{d.raw}“ trägt zusätzlich "
                    f"eine Toleranz",
                    bbox=d.bbox, page=d.page,
                    detail="Ein eingerahmtes Maß (TED) ist per Definition "
                           "toleranzfrei; die Abweichung regelt allein die "
                           "zugehörige Lagetoleranz (ISO 1101). Entweder den "
                           "Rahmen entfernen oder die Toleranz streichen.")


def check_roughness_vs_tolerance(ctx: CheckContext,
                                 dims: list[DimValue]) -> None:
    """Rauheit gegen die engste Maßtoleranz prüfen.

    Praxisregel: Das Rauheitsprofil darf die Maßtoleranz nicht aufzehren.
    Üblich ist Rz ≤ 1/4 der Toleranzbreite; gemeldet wird erst ab der
    Hälfte, damit nur eindeutige Widersprüche auffallen.
    """
    if not ctx.profile.enabled("SURF.TOL_MISMATCH"):
        return
    coarsest = _coarsest_roughness_um(ctx)
    if coarsest is None:
        return
    tightest = None
    for d in dims:
        span = d.tolerance_span
        if span and (tightest is None or span < tightest[0]):
            tightest = (span, d)
    if tightest is None:
        return
    span_mm, dim = tightest
    span_um = span_mm * 1000.0
    ratio = float(ctx.profile.rule_param("SURF.TOL_MISMATCH", "max_ratio", 0.5))
    if coarsest <= span_um * ratio:
        return
    ctx.add("SURF.TOL_MISMATCH",
            f"Rauheit Rz {coarsest:g} µm ist zu grob für die Toleranz von "
            f"„{dim.raw}“ ({span_um:.0f} µm)",
            bbox=dim.bbox, page=dim.page,
            detail=f"Das Rauheitsprofil verbraucht "
                   f"{coarsest / span_um * 100:.0f} % der Toleranzbreite; "
                   f"üblich sind höchstens 25 %. Entweder eine feinere "
                   f"Oberfläche fordern (Rz ≤ {span_um / 4:.1f} µm) oder die "
                   f"Toleranz aufweiten. Sonst ist das Maß nicht "
                   f"reproduzierbar messbar.")


def _coarsest_roughness_um(ctx: CheckContext) -> float | None:
    """Gröbste Rauheitsangabe der Zeichnung als Rz in µm.

    Ra-Angaben werden mit dem in der Praxis üblichen Faktor 4 auf Rz
    umgerechnet (Rz ≈ 4 × Ra für spanend erzeugte Oberflächen).
    """
    text = ctx.pdf.full_text()
    values: list[float] = []
    for m in RE_RZ_VALUE.finditer(text):
        values.append(_num(m.group(1)))
    for m in RE_RA_VALUE.finditer(text):
        values.append(_num(m.group(1)) * 4.0)
    values = [v for v in values if 0 < v <= 200]
    return max(values) if values else None


def _num(raw: str) -> float:
    return float(raw.replace(",", "."))


# Mindest-Einschraubtiefe als Vielfaches des Nenndurchmessers. Faustwerte
# der Verbindungstechnik (VDI 2230): Stahl 1×D, Guss 1,25×D, Alu 1,5–2×D.
MIN_ENGAGEMENT = {"stahl": 1.0, "guss": 1.25, "alu": 1.5}
RE_SOFT_MATERIAL = re.compile(
    r"\bAl(?:Mg|Si|Cu|Zn)|EN\s?AW|aluminium|\bGD-?Al|kunststoff|\bPA6|POM",
    re.IGNORECASE)


def check_thread_depths(ctx: CheckContext, dims: list[DimValue]) -> None:
    """Gewindetiefe gegen Bohrtiefe und gegen die Mindesteinschraubtiefe.

    Beide Fälle stehen auf der Zeichnung, werden aber selten gegengerechnet:
    „M10 ↧25" mit „⌀8,5 ↧20" ist nicht herstellbar, und „M10 ↧6" trägt in
    Aluminium nicht.
    """
    threads = [d for d in dims if d.kind is DimKind.THREAD and d.depth]
    if not threads:
        return
    weich = bool(RE_SOFT_MATERIAL.search(ctx.pdf.full_text()))
    faktor = MIN_ENGAGEMENT["alu"] if weich else MIN_ENGAGEMENT["stahl"]
    bohrungen = [d for d in dims if d.kind is DimKind.DIAMETER and d.depth]

    for t in threads:
        if ctx.profile.enabled("THRD.DEPTH"):
            core = _core_hole(t.value)
            passende = [b for b in bohrungen
                        if core and abs(b.value - core) <= 0.6]
            for b in passende:
                if t.depth > b.depth + 0.5:
                    ctx.add("THRD.DEPTH",
                            f"Gewinde „{t.raw}“ ist {t.depth:g} mm tief "
                            f"gefordert, die Bohrung ⌀{b.value:g} nur "
                            f"{b.depth:g} mm",
                            bbox=t.bbox, page=t.page,
                            detail="Das Gewinde kann nicht tiefer sein als "
                                   "die Kernbohrung. Üblich sind 2–5 mm "
                                   "Bohrungsüberlauf für den Gewindeauslauf "
                                   "(bei Grundlöchern zwingend).")
                    break
        if ctx.profile.enabled("THRD.SHORT") and t.depth < t.value * faktor:
            werkstoff = "weichem Werkstoff (Alu/Kunststoff)" if weich else "Stahl"
            ctx.add("THRD.SHORT",
                    f"Einschraubtiefe {t.depth:g} mm bei „{t.raw}“ ist kurz – "
                    f"in {werkstoff} sind mindestens "
                    f"{t.value * faktor:.0f} mm üblich",
                    bbox=t.bbox, page=t.page,
                    detail="Unter etwa 1×D (Stahl) bzw. 1,5×D (Aluminium) "
                           "reißt das Gewinde aus, bevor die Schraube ihre "
                           "Festigkeit erreicht (VDI 2230). Entweder tiefer "
                           "gewinden oder Gewindeeinsatz vorsehen.")


def _core_hole(nominal: float) -> float | None:
    from .geometry_checks import THREAD_CORE_DIA

    return THREAD_CORE_DIA.get(int(nominal))


def run_dimension_checks(ctx: CheckContext, dims: list[DimValue]) -> None:
    check_dimension_chain(ctx, dims)
    check_tight_tolerances(ctx, dims)
    check_deep_holes(ctx, dims)
    check_sharp_corners(ctx)
    check_surface_plausibility(ctx)
    check_tolerance_order(ctx, dims)
    check_roughness_vs_tolerance(ctx, dims)
    check_thread_depths(ctx, dims)
